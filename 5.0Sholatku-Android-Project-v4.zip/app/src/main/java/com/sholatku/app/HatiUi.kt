package com.sholatku.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

/**
 * Tampilan HATI-HATI. Tetap tampil sampai tombol TUTUP ditekan dan ditahan 5 detik.
 * Selisih menit dihitung langsung dari waktu Iqomah ke waktu sekarang (diperbarui tiap detik).
 */
object HatiUi {
    const val HOLD_MS = 5000L

    fun build(ctx: Context, h: Handler, name: String, iqMs: Long, onClose: () -> Unit): View {
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
        val amber = Color.parseColor("#E8B4A0")
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0A1630"), Color.parseColor("#1F3A6E"))
        )

        val warn = Icons.bubble(ctx, R.drawable.ic_warn, 104, Color.parseColor("#2EE8B4A0"), amber)

        val title = TextView(ctx)
        title.text = "HATI-HATI"
        title.textSize = 40f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(amber)
        title.gravity = Gravity.CENTER
        title.setPadding(0, dp(14), 0, dp(18))

        fun line(bold: Boolean, color: Int): TextView {
            val t = TextView(ctx)
            t.textSize = 18f
            if (bold) t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(color)
            t.gravity = Gravity.CENTER_VERTICAL
            return t
        }

        val m1 = line(true, Color.WHITE)
        val m2 = line(false, Color.WHITE)
        val m3 = line(false, amber)
        val r1 = Icons.row(ctx, R.drawable.ic_mosque, Color.WHITE, m1)
        val r2 = Icons.row(ctx, R.drawable.ic_clock, Color.WHITE, m2)
        val r3 = Icons.row(ctx, R.drawable.ic_hourglass, amber, m3)
        for (r in listOf(r1, r2, r3)) r.setPadding(0, dp(6), 0, dp(6))
        r3.setPadding(0, dp(6), 0, dp(34))

        val upd = object : Runnable {
            override fun run() {
                val now = System.currentTimeMillis()
                val c = Calendar.getInstance()
                val mnt = Math.max(0L, (now - iqMs) / 60000L)
                m1.text = "Sholat $name $mnt menit telah berlalu"
                m2.text = "Sekarang: " + String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                m3.text = "Telah berlalu: $mnt menit sejak Iqomah"
                h.postDelayed(this, 1000)
            }
        }
        upd.run()

        // ---- tombol TUTUP (tahan 5 detik) ----
        val hold = LinearLayout(ctx)
        hold.orientation = LinearLayout.HORIZONTAL
        hold.gravity = Gravity.CENTER
        hold.setPadding(dp(28), dp(16), dp(28), dp(16))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#33FFFFFF"))
        bg.cornerRadius = dp(32).toFloat()
        bg.setStroke(dp(1), Color.parseColor("#55FFFFFF"))
        hold.background = bg
        val ck = Icons.view(ctx, R.drawable.ic_check, 22, Color.parseColor("#5FD9A0"))
        (ck.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, dp(10), 0)
        val holdTx = TextView(ctx)
        holdTx.textSize = 15f
        holdTx.typeface = Typeface.DEFAULT_BOLD
        holdTx.setTextColor(Color.WHITE)
        holdTx.gravity = Gravity.CENTER
        val idle = "TUTUP (Tahan 5 detik)"
        holdTx.text = idle
        hold.addView(ck)
        hold.addView(holdTx)

        var t0 = 0L
        val closeRun = Runnable { onClose() }
        val tickHold = object : Runnable {
            override fun run() {
                val left = Math.max(1L, (HOLD_MS - (System.currentTimeMillis() - t0) + 999L) / 1000L)
                holdTx.text = "TERUS TAHAN… $left"
                h.postDelayed(this, 250)
            }
        }
        hold.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    t0 = System.currentTimeMillis()
                    tickHold.run()
                    h.postDelayed(closeRun, HOLD_MS)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(tickHold)
                    h.removeCallbacks(closeRun)
                    holdTx.text = idle
                }
            }
            true
        }

        root.addView(warn)
        root.addView(title)
        root.addView(r1)
        root.addView(r2)
        root.addView(r3)
        root.addView(hold)

        val anim = ObjectAnimator.ofFloat(warn, "alpha", 1f, 0.3f).apply {
            duration = 800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) {
                anim.cancel()
                h.removeCallbacks(upd)
                h.removeCallbacks(tickHold)
                h.removeCallbacks(closeRun)
            }
        })
        return root
    }
}
