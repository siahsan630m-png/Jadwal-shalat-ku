package com.sholatku.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Ikon vektor bergaya garis (bersih, modern) menggantikan emoji. */
object Icons {
    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /** Ikon polos berwarna [tint]. */
    fun view(ctx: Context, res: Int, sizeDp: Int, tint: Int): ImageView {
        val iv = ImageView(ctx)
        iv.setImageResource(res)
        iv.setColorFilter(tint)
        iv.layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        return iv
    }

    /** Ikon di dalam lingkaran berwarna. */
    fun bubble(ctx: Context, res: Int, sizeDp: Int, bg: Int, tint: Int = Color.WHITE): ImageView {
        val iv = ImageView(ctx)
        iv.setImageResource(res)
        iv.setColorFilter(tint)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(bg)
        iv.background = g
        val p = dp(ctx, sizeDp) / 4
        iv.setPadding(p, p, p, p)
        iv.layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        return iv
    }

    /** Baris: ikon kecil + teks. */
    fun row(ctx: Context, res: Int, tint: Int, tv: TextView): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        val ic = view(ctx, res, 22, tint)
        (ic.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, dp(ctx, 10), 0)
        r.addView(ic)
        r.addView(tv)
        return r
    }

    @Suppress("unused")
    fun hide(v: View) { v.visibility = View.GONE }
}
