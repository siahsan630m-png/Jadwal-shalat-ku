package com.sholatku.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Semua jendela mengambang (WindowManager + SYSTEM_ALERT_WINDOW):
 *  - dzikir: tulisan di ATAS layar, tombol - dan + di BAWAH layar
 *  - kartu azan / iqomah di atas layar
 *  - layar penuh HATI-HATI
 */
class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())

    var onPlus: (() -> Unit)? = null
    var onMinus: (() -> Unit)? = null
    var onCloseDzikir: (() -> Unit)? = null
    var onCallClosed: (() -> Unit)? = null
    var onHatiClosed: (() -> Unit)? = null

    private var dzTop: View? = null
    private var dzBottom: View? = null
    private var tvCount: TextView? = null
    private var tvName: TextView? = null
    private var tvAr: TextView? = null
    private var callView: View? = null
    private var callAnim: ObjectAnimator? = null
    private var hatiView: View? = null

    private val autoHideCall = Runnable { hideCall(false) }

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun sysDim(name: String): Int {
        val id = ctx.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }

    private fun round(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = r.toFloat()
        return g
    }

    private fun params(w: Int, hh: Int, gravity: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val p = WindowManager.LayoutParams(
            w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        p.gravity = gravity
        return p
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun circle(txt: String, sizeDp: Int, textSp: Float, bg: String, fg: String, click: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = txt
        t.gravity = Gravity.CENTER
        t.textSize = textSp
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(Color.parseColor(fg))
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.parseColor(bg))
        t.background = g
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        lp.setMargins(dp(6), 0, dp(6), 0)
        t.layoutParams = lp
        t.setOnClickListener { click() }
        return t
    }

    // ------------------------------------------------------------------ DZIKIR

    fun showDzikir(n: Int, target: Int, size: String, name: String = "Istighfar", arabic: String = "أَسْتَغْفِرُ اللهَ") {
        if (!canDraw()) return
        hideDzikir()
        try {
            // ---- ATAS: tulisan dzikir (tidak menghalangi sentuhan) ----
            val top = LinearLayout(ctx)
            top.orientation = LinearLayout.VERTICAL
            top.gravity = Gravity.CENTER_HORIZONTAL
            top.setPadding(dp(22), dp(10), dp(22), dp(10))
            top.background = round("#EB0F1E3D", dp(22))

            val ar = TextView(ctx)
            ar.text = arabic
            ar.visibility = if (arabic.isEmpty()) View.GONE else View.VISIBLE
            ar.maxLines = 2
            ar.ellipsize = android.text.TextUtils.TruncateAt.END
            ar.textSize = when (size) { "s" -> 24f; "l" -> 36f; else -> 30f }
            ar.setTextColor(Color.WHITE)
            ar.gravity = Gravity.CENTER

            val nm = TextView(ctx)
            nm.text = name
            nm.maxLines = 2
            nm.textSize = 13f
            nm.setTextColor(Color.parseColor("#B8C4DA"))
            nm.gravity = Gravity.CENTER

            val cnt = TextView(ctx)
            cnt.textSize = when (size) { "s" -> 18f; "l" -> 28f; else -> 22f }
            cnt.typeface = Typeface.DEFAULT_BOLD
            cnt.setTextColor(Color.parseColor("#E8B4A0"))
            cnt.gravity = Gravity.CENTER
            cnt.text = "$n / $target"
            tvCount = cnt
            tvName = nm
            tvAr = ar

            top.addView(ar)
            top.addView(nm)
            top.addView(cnt)
            val pt = params(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL, false
            )
            pt.y = sysDim("status_bar_height") + dp(8)
            wm.addView(top, pt)
            dzTop = top

            // ---- BAWAH: tombol - dan + ----
            val sMinus = when (size) { "s" -> 52; "l" -> 84; else -> 68 }
            val sPlus = when (size) { "s" -> 68; "l" -> 112; else -> 88 }
            val sClose = when (size) { "s" -> 38; "l" -> 50; else -> 44 }
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(12), dp(10))
            row.background = round("#EB0F1E3D", dp(60))
            row.addView(circle("✕", sClose, 16f, "#3A4F7A", "#FFFFFF") { onCloseDzikir?.invoke() })
            row.addView(circle("−", sMinus, 28f, "#DCE4F2", "#1F3A6E") { onMinus?.invoke() })
            row.addView(circle("+", sPlus, 40f, "#E8B4A0", "#2B1810") { onPlus?.invoke() })
            val pb = params(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, true
            )
            pb.y = sysDim("navigation_bar_height") + dp(16)
            wm.addView(row, pb)
            dzBottom = row
        } catch (e: Exception) {
            hideDzikir()
        }
    }

    fun updateDzikir(n: Int, target: Int, name: String? = null, arabic: String? = null) {
        tvCount?.text = "$n / $target"
        if (name != null) tvName?.text = name
        if (arabic != null) {
            tvAr?.text = arabic
            tvAr?.visibility = if (arabic.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    fun hideDzikir() {
        safeRemove(dzTop); safeRemove(dzBottom)
        dzTop = null; dzBottom = null; tvCount = null; tvName = null; tvAr = null
    }

    fun dzikirShown(): Boolean = dzTop != null

    // ------------------------------------------------------------ KARTU AZAN / IQOMAH

    /** kind: "a" (merah, azan) atau "i" (hijau, iqomah) */
    fun showCall(kind: String, title: String, sub: String, autoMs: Long) {
        if (!canDraw()) return
        hideCall(false)
        try {
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(14), dp(14), dp(14), dp(14))
            card.background = round("#0F1E3D", dp(22))

            val ic = Icons.bubble(ctx, R.drawable.ic_bell, 52, Color.parseColor(if (kind == "i") "#30A46C" else "#E5484D"))

            val tx = LinearLayout(ctx)
            tx.orientation = LinearLayout.VERTICAL
            val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            tlp.setMargins(dp(12), 0, dp(8), 0)
            tx.layoutParams = tlp
            val t1 = TextView(ctx)
            t1.text = title
            t1.textSize = 18f
            t1.typeface = Typeface.DEFAULT_BOLD
            t1.setTextColor(Color.WHITE)
            val t2 = TextView(ctx)
            t2.text = sub
            t2.textSize = 14f
            t2.setTextColor(Color.parseColor("#B8C4DA"))
            tx.addView(t1)
            tx.addView(t2)

            val close = circle("✕", 44, 18f, "#3A4F7A", "#FFFFFF") { hideCall(true) }
            (close.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, 0, 0)

            card.addView(ic)
            card.addView(tx)
            card.addView(close)

            val width = ctx.resources.displayMetrics.widthPixels - dp(20)
            val p = params(width, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            p.y = sysDim("status_bar_height") + dp(8)
            card.translationY = -dp(180).toFloat()
            wm.addView(card, p)
            card.animate().translationY(0f).setDuration(450).start()
            callView = card

            callAnim = ObjectAnimator.ofPropertyValuesHolder(
                ic,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.14f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.14f)
            ).apply {
                duration = 500
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                start()
            }
            h.removeCallbacks(autoHideCall)
            h.postDelayed(autoHideCall, autoMs)
        } catch (e: Exception) {
            hideCall(false)
        }
    }

    /** Kartu "MENDEKATI WAKTU AZAN" dengan tombol Batal dan Lihat Jadwal (memakai slot kartu yang sama, jadi tidak menumpuk). */
    fun showPre(title: String, body: String, sub: String, autoMs: Long, onSee: () -> Unit) {
        if (!canDraw()) return
        hideCall(false)
        try {
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(16), dp(14), dp(16), dp(14))
            card.background = round("#0F1E3D", dp(22))

            val head = LinearLayout(ctx)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            val ic = Icons.bubble(ctx, R.drawable.ic_bell, 40, Color.parseColor("#E8A23A"))
            val t1 = TextView(ctx)
            t1.text = title
            t1.textSize = 16f
            t1.typeface = Typeface.DEFAULT_BOLD
            t1.setTextColor(Color.WHITE)
            t1.setPadding(dp(12), 0, 0, 0)
            head.addView(ic)
            head.addView(t1)

            val t2 = TextView(ctx)
            t2.text = body
            t2.textSize = 16f
            t2.setTextColor(Color.WHITE)
            t2.setPadding(0, dp(12), 0, dp(2))
            val t3 = TextView(ctx)
            t3.text = sub
            t3.textSize = 14f
            t3.setTextColor(Color.parseColor("#B8C4DA"))

            fun btn(label: String, bg: String, fg: String, click: () -> Unit): TextView {
                val b = TextView(ctx)
                b.text = label
                b.textSize = 14f
                b.typeface = Typeface.DEFAULT_BOLD
                b.gravity = Gravity.CENTER
                b.setTextColor(Color.parseColor(fg))
                b.background = round(bg, dp(24))
                b.setPadding(dp(8), dp(12), dp(8), dp(12))
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(4), 0, dp(4), 0)
                b.layoutParams = lp
                b.setOnClickListener { click() }
                return b
            }

            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, dp(14), 0, 0)
            row.addView(btn("Batal", "#3A4F7A", "#FFFFFF") { hideCall(false) })
            row.addView(btn("Lihat Jadwal", "#E8B4A0", "#2B1810") { hideCall(false); onSee() })

            card.addView(head)
            card.addView(t2)
            card.addView(t3)
            card.addView(row)

            val width = ctx.resources.displayMetrics.widthPixels - dp(20)
            val p = params(width, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
            p.y = sysDim("status_bar_height") + dp(8)
            card.translationY = -dp(200).toFloat()
            wm.addView(card, p)
            card.animate().translationY(0f).setDuration(450).start()
            callView = card
            h.removeCallbacks(autoHideCall)
            h.postDelayed(autoHideCall, autoMs)
        } catch (e: Exception) {
            hideCall(false)
        }
    }

    /** [byUser] = true bila ditutup lewat tombol ✕ (suara ikut dihentikan). */
    fun hideCall(byUser: Boolean) {
        h.removeCallbacks(autoHideCall)
        callAnim?.cancel(); callAnim = null
        safeRemove(callView); callView = null
        if (byUser) onCallClosed?.invoke()
    }

    // ------------------------------------------------------------------ HATI-HATI

    fun showHati(name: String, iqMs: Long) {
        if (!canDraw()) return
        hideHati(false)
        try {
            val root = HatiUi.build(ctx, h, name, iqMs) { hideHati(true) }
            val p = params(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                Gravity.TOP or Gravity.START, true
            )
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            wm.addView(root, p)
            hatiView = root
        } catch (e: Exception) {
            hideHati(false)
        }
    }

    fun hideHati(byUser: Boolean) {
        safeRemove(hatiView); hatiView = null
        if (byUser) onHatiClosed?.invoke()
    }

    fun hideAll() {
        hideDzikir(); hideCall(false); hideHati(false)
    }
}
