package com.sholatku.app

import android.content.Context
import org.json.JSONObject

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("sholatku", Context.MODE_PRIVATE)

    private var raw: String? = null
    private var obj: JSONObject = JSONObject()

    @Synchronized
    fun cfg(c: Context): JSONObject {
        val s = sp(c).getString("cfg", null) ?: return JSONObject()
        if (s != raw) {
            obj = try { JSONObject(s) } catch (e: Exception) { JSONObject() }
            raw = s
        }
        return obj
    }

    fun saveCfg(c: Context, json: String): Boolean {
        val o = try { JSONObject(json) } catch (e: Exception) { return false }
        sp(c).edit().putString("cfg", json).apply()
        val n = o.optJSONObject("dz")?.optInt("n", -1) ?: -1
        if (n >= 0) setCount(c, n)
        return true
    }

    /** -1 = belum pernah diset */
    fun count(c: Context): Int = sp(c).getInt("dz_n", -1)
    fun setCount(c: Context, n: Int) { sp(c).edit().putInt("dz_n", n).apply() }

    fun dzikirOn(c: Context): Boolean = sp(c).getBoolean("dz_on", false)
    fun setDzikirOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("dz_on", on).apply() }
}
