package com.sholatku.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.LoudnessEnhancer
import android.os.PowerManager
import org.json.JSONObject
import java.io.File

/**
 * Pemutar azan / iqomah / hati².
 *
 * Pengaturan suara (per jenis, dari JSON [s]):
 *  - vol  : volume pemutar 0..1 (mode "full" = selalu 1)
 *  - vm   : volume sistem (stream ALARM): "max" = naik ke 100% lalu dikembalikan,
 *           "cus" = persen sendiri ([sv]), "hp" = ikut tombol volume HP (tidak diubah)
 *  - sv   : persen volume sistem bila vm = "cus"
 *  - bst  : penguat suara 0 = mati, 1 = +6 dB, 2 = +12 dB (untuk rekaman yang pelan)
 */
class SoundPlayer(private val c: Context) {
    private var mp: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private var enhancer: LoudnessEnhancer? = null
    private var savedVol = -1
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private fun newPlayer(): MediaPlayer {
        val m = MediaPlayer()
        m.setAudioAttributes(attrs)
        m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
        return m
    }

    private fun build(pick: String, rawId: Int): MediaPlayer {
        if (pick.isNotEmpty() && Regex("[A-Za-z0-9_-]+").matches(pick)) {
            val f = File(File(c.filesDir, "audio"), pick)
            if (f.exists()) {
                val m = newPlayer()
                try {
                    m.setDataSource(f.absolutePath)
                    return m
                } catch (e: Exception) {
                    m.release()
                }
            }
        }
        val m = newPlayer()
        val afd = c.resources.openRawResourceFd(rawId)
        m.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        afd.close()
        return m
    }

    private fun takeFocus() {
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { }
                .build()
            am.requestAudioFocus(req)
            focus = req
        } catch (e: Exception) {
        }
    }

    private fun dropFocus() {
        try {
            focus?.let { am.abandonAudioFocusRequest(it) }
        } catch (e: Exception) {
        }
        focus = null
    }

    /** Naikkan volume stream ALARM sesuai pengaturan; volume lama disimpan untuk dikembalikan. */
    private fun applySystemVolume(mode: String, pct: Int) {
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val target = when (mode) {
                "max" -> max
                "cus" -> Math.round(max * pct.coerceIn(0, 100) / 100f).coerceIn(1, max)
                else -> return
            }
            if (savedVol < 0) savedVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
        } catch (e: Exception) {
        }
    }

    private fun restoreSystemVolume() {
        if (savedVol >= 0) {
            try {
                am.setStreamVolume(AudioManager.STREAM_ALARM, savedVol, 0)
            } catch (e: Exception) {
            }
        }
        savedVol = -1
    }

    private fun attachBoost(m: MediaPlayer, level: Int) {
        if (level <= 0) return
        try {
            val e = LoudnessEnhancer(m.audioSessionId)
            e.setTargetGain(if (level >= 2) 1200 else 600)
            e.enabled = true
            enhancer = e
        } catch (e: Exception) {
        }
    }

    /** kind: "azan" | "iq" | "ht" */
    fun play(kind: String, pick: String, s: JSONObject, loop: Boolean, onDone: (() -> Unit)?) {
        stop()
        try {
            takeFocus()
            val rawId = when (kind) {
                "azan" -> R.raw.azan
                "iq" -> R.raw.iqomah
                else -> R.raw.hati
            }
            val full = s.optString("mode", "ring") == "full"
            val v = if (full) 1f else s.optDouble("vol", 1.0).toFloat().coerceIn(0f, 1f)
            applySystemVolume(s.optString("vm", "max"), s.optInt("sv", 100))
            val boost = s.optInt("bst", 1)
            val m = build(pick, rawId)
            m.isLooping = loop
            m.setVolume(v, v)
            m.setOnPreparedListener {
                attachBoost(it, boost)
                it.start()
            }
            m.setOnCompletionListener {
                if (mp === it) {
                    stop()
                    onDone?.invoke()
                }
            }
            m.setOnErrorListener { p, _, _ ->
                if (mp === p) {
                    stop()
                    onDone?.invoke()
                }
                true
            }
            mp = m
            m.prepareAsync()
        } catch (e: Exception) {
            stop()
            onDone?.invoke()
        }
    }

    fun stop() {
        try { enhancer?.release() } catch (e: Exception) { }
        enhancer = null
        mp?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        mp = null
        restoreSystemVolume()
        dropFocus()
    }
}
